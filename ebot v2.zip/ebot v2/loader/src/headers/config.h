#pragma once

#define HTTP_SERVER "185.44.81.114"
#define HTTP_PORT 80

#define TFTP_SERVER "185.44.81.114"
